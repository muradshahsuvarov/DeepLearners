package Icefield;

public class Rope extends Object{

	@Override
	public void Used() {
		System.out.println("Rope was taken! ");
	}

	@Override
	public boolean isUsed() {
		
		// Logic: Checks whether flare is used or not
		
		return false;
	}

	
	public void Use() {
		
		// Logic
	}
	
	

}
