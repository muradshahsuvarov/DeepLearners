package Icefield;

public class DivingSuit extends Object{
	
	public void showOnGUI()
	{
		// Logic: show this object in GUI
	}

	@Override
	public void Used() {
		System.out.println("DivingSuit was taken!");
	}
	@Override
	public boolean isUsed() {
		// Logic: Checks whether diving suit is used or not
		return false;
	}
	
public void Use() {
		
		// Logic
	}

	
}
