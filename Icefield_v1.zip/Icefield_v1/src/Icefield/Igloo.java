package Icefield;

public class Igloo extends Object{

	@Override
	public void Used() {
		System.out.println("Igloo was set!");
	}
	@Override
	public boolean isUsed() {
		// Logic: Checks whether igloo is used or not
		return false;
	}
	
public void Use() {
		
		// Logic
	}


}
