package Icefield;

public class GUI {
	
	// Main menus of the game which GUI class implements
	public MainMenu mainMenu;
	public Settings settings;
	
	// GUI of the actual game
	public Map map;
	
	
	public GUI(int height, int width)
	{
		mainMenu = new MainMenu();
		settings = new Settings();
		map = new Map(height, width, Map.getPlayers());
	}
	
	
	public void ShowGUI()
	{
		// Logic: Show GUI.
		// Actual Game life cycle
		
	}
	
	public void EndGUI()
	{
		// Logic: End GUI
		// End the GUI after game is closed
	}
	

}
