package Icefield;

public class Settings {

}
