package Icefield;

public class Food extends Object {

	@Override
	public void Used() {
		System.out.println("Food was taken!");
	}
	@Override
	public boolean isUsed() {
		// Logic: Checks whether food is used or not
		return false;
	}
	
public void Use() {
		
		// Logic
	}
	
}
