package Icefield;

public class Flare extends Object {
	
	@Override
	public void Used() {
		System.out.println("Flare was taken!");
	}
	@Override
	public boolean isUsed() {
		// Logic: Checks whether flare is used or not
		return false;
	}
	
	
	

}
