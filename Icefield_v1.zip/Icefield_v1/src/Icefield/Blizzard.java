package Icefield;

public class Blizzard extends Matrix{

	// Coordinates of the Blizzard
	private int x;
	private int y;

	public Blizzard(int height, int width, int x, int y) {
		super(height, width);
		// TODO Auto-generated constructor stub
	}
	
	public void StartBlizzard()
	{
		// Logic: Start the Blizzard, Increment number of snow on the iceberg
	}
	
	public void StopBlizzard()
	{
		// Logic: Stop the Blizzard
	}
	

}
