package Icefield;

public class Shovel extends Object{

@Override
public void Used() {
	System.out.println("Food was used!");
	
}

@Override
public boolean isUsed() {
	// Logic: Checks whether shovel is used or not
	return false;
}

public void Use() {
	
	// Logic
}


}
