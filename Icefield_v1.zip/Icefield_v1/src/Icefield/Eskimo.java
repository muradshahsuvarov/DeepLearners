package Icefield;

public class Eskimo extends Figure{
	
	public Eskimo(String Name, int Health, int SkillsCount, int ItemsCount) {
		super(Name, Health, SkillsCount, ItemsCount);
	}

	@Override
	public void Skill_Use()
	{
		// Logic: build igloo
	}
	

}
